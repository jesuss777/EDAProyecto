package Clases;
public class Interesado {
    private int DNI;
    private String NombreCompleto;
    private int telefono;
    private String email;
    
    public Interesado(int DNI, String NombreCompleto, String email, int telefono) {
        this.DNI = DNI;
        this.NombreCompleto = NombreCompleto;
        this.email = email;
        this.telefono = telefono;
    }
    
    public int getDNI() {
        return DNI;
    }
    public void setDNI(int DNI) {
        this.DNI = DNI;
    }
    
    public String getNombreCompleto() {
        return NombreCompleto;
    }
    public void setNombreCompleto(String Nombre) {
        this.NombreCompleto = Nombre;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public int getTelefono() {
        return telefono;
    }
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    
    
}
