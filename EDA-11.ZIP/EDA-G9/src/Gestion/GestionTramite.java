package Gestion;
import Clases.*;
import TDA.*;

public class GestionTramite {
    private Pila<Tramites> GestionTramites;
    
    public GestionTramite() {
        this.GestionTramites = new Pila<>();
    }

    public Pila<Tramites> getGestionTramites() {
        return GestionTramites;
    }

    public void setGestionTramites(Pila<Tramites> GestionTramites) {
        this.GestionTramites = GestionTramites;
    }
    
    public void AgregarTramite(Tramites T){
        GestionTramites.push(T);
    }
    
    public void FinalizarTramite(){
        GestionTramites.pop();
    }
}
