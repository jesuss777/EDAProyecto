package Clases;

public class Tramites {
    private String Certificados = "CERTIFICADOS";
    private String Constancias = "CONSTANCIA";
    private String CarnetUniversitario = "CARNET_UNIVERSITARIO";
    private String CarnetDeLicencia = "LICENCIA";
    private String Reclamos = "RECLAMO";
    private String HistorialAcademico = "HISTORIAL_ACADEMICO"; 


    
}
