package Gestion;
public class GestionDependencias {
    
}
