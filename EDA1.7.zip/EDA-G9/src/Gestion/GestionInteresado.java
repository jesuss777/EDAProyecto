package Gestion;
import Clases.*;
import TDA.*;
import java.util.EmptyStackException;
public class GestionInteresado {
    private Pila<Interesado> GestionInt;

    public GestionInteresado() {
        this.GestionInt = new Pila<>();
    }

    public Pila<Interesado> getGestionInt() {
        return GestionInt;
    }

    public void setGestionInt(Pila<Interesado> GestionInt) {
        this.GestionInt = GestionInt;
    }
    
    public void AgregarInteresado(Interesado inte){
        GestionInt.push(inte);
    }
    public void EliminarInteresado() {
        if (!GestionInt.isEmpty()) {
            GestionInt.pop();
        } else {
            System.out.println("ERROR: no es posible eliminar, la pila está vacía");
        }
    }
            
    public Interesado obtenerUltimoInteresado() {
        if (!GestionInt.isEmpty()) {
            return GestionInt.top();
        } else {
            return null;
        }
    }
    
    public String obtenerNombreUltimoInteresado() {
        Interesado ultimoInteresado = obtenerUltimoInteresado();
        if (ultimoInteresado != null) {
            return ultimoInteresado.getNombreCompleto();
        } else {
            return "ERROR: no es posible devolver cima, la pila está vacía";
        }
    }
    
    public Interesado buscarInteresadoPorNombre(String nombre) {
        Pila<Interesado> aux = new Pila<>();
        Interesado interesadoEncontrado = null;

        // Mover elementos de GestionInt a aux y buscar el interesado
        while (!GestionInt.isEmpty()) {
            Interesado inte = GestionInt.pop();
            aux.push(inte);
            if (inte.getNombreCompleto().equals(nombre)) {
                interesadoEncontrado = inte;
                break;
            }
        }

        // Restaurar los elementos a GestionInt
        while (!aux.isEmpty()) {
            GestionInt.push(aux.pop());
        }

        return interesadoEncontrado;
    }
}
