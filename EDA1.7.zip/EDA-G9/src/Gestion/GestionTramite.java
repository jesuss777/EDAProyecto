package Gestion;
import Clases.*;
import TDA.*;

public class GestionTramite {
    private Lista<Tramites> GestionTramites;

    public GestionTramite() {
        this.GestionTramites = new Lista<>();
    }

    public Lista<Tramites> getGestionTramites() {
        return GestionTramites;
    }

    public void setGestionTramites(Lista<Tramites> GestionTramites) {
        this.GestionTramites = GestionTramites;
    }
    
    public void AgregarTramite(Tramites T){
        GestionTramites.agregar(T);
    }
    
}
