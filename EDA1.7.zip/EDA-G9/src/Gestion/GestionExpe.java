package Gestion;

import Clases.*;
import TDA.*;

public class GestionExpe {
    private Cola<Expediente> GestionExpediente;

    public GestionExpe() {
        this.GestionExpediente = new Cola<>();
    }

    public Cola<Expediente> getGestionExpediente() {
        return GestionExpediente;
    }

    public void setGestionExpediente(Cola<Expediente> GestionExpediente) {
        this.GestionExpediente = GestionExpediente;
    }
    
    public void AgregarExpediente(Expediente expe){
        GestionExpediente.encolar(expe);
    }
    
    public void EliminarExpediente(){
        GestionExpediente.desencolar();
    }
    
    public Expediente obtenerUltimoInteresado(){
        if(!GestionExpediente.esVacia()){
            Nodo<Expediente> ultimoN = GestionExpediente.getUltimo();
            return ultimoN.getElemento();
        }
        else{
            return null;
        }
    }
    
}
