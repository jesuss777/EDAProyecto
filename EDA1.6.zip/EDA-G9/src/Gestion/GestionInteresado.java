package Gestion;
public class GestionInteresado {
    
}
