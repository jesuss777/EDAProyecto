package Gestion;
import Clases.*;
import TDA.*;
public class GestionAdmin {
    private Lista<Administrador> GestionAdmin;
    private String nombreUsuarioSesion;


    public GestionAdmin() {
        this.GestionAdmin = new Lista<>();
    }
    
    public Lista<Administrador> getGestionAdmin() {
        return GestionAdmin;
    }

    public void setGestionAdmin(Lista<Administrador> GestionAdmin) {
        this.GestionAdmin = GestionAdmin;
    }
    
    
    public void AgregarAdmin(Administrador admin){
        GestionAdmin.agregar(admin);
    }
    
    public Administrador iesimo(int pos) {
        return GestionAdmin.iesimo(pos);
    }
    
    public Administrador obtenerAdminPorUsuario(String usuario) {
        for (int i = 0; i < GestionAdmin.longitud(); i++) {
            Administrador admin = GestionAdmin.iesimo(i);
            if (admin != null && admin.getUsuario().equals(usuario)) {
                return admin;
            }
        }
        return null;
    }
    
    public void setNombreUsuarioSesion(String nombreUsuario) {
        this.nombreUsuarioSesion = nombreUsuario;
    }

    public String getNombreUsuarioSesion() {
        return nombreUsuarioSesion;
    }
    
    
    
}
