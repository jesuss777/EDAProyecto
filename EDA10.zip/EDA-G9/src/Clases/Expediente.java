package Clases;
public class Expediente {
    
    private int id;
    private String prioridad;
    private Interesado datosInteresado;
    private String asunto;
    private String docRef;
    private String estado;
    
    public Expediente(int id, String prioridad, Interesado datosInteresado, String asunto, String docRef) {
        this.id = id;
        this.prioridad = prioridad;
        this.datosInteresado = datosInteresado;
        this.asunto = asunto;
        this.docRef = docRef;
        this.estado = "En trámite";
    }
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getPrioridad() {
        return prioridad;
    }
    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }
    public Interesado getDatosInteresado() {
        return datosInteresado;
    }
    public void setDatosInteresado(Interesado datosInteresado) {
        this.datosInteresado = datosInteresado;
    }
    public String getAsunto() {
        return asunto;
    }
    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }
    public String getDocRef() {
        return docRef;
    }
    public void setDocRef(String docRef) {
        this.docRef = docRef;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public String cbExpediente(){
        return  id+"-"+datosInteresado.getNombreCompleto();
    }
    
    public String NombreInteresado(){
        return datosInteresado.getNombreCompleto();
    }
}
