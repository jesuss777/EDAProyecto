package Gestion;

import Clases.*;
import TDA.*;

public class GestionDependencias {
    Lista<Dependencias> GestionDepe;

    public GestionDependencias() {
        this.GestionDepe = new Lista<>();
    }

    public Lista<Dependencias> getGestionDepe() {
        return GestionDepe;
    }

    public void setGestionDepe(Lista<Dependencias> GestionDepe) {
        this.GestionDepe = GestionDepe;
    }
    
    
    
    
    
    
}
