package Clases;

import TDA.*;
import java.util.Date;

public class Tramites {
    
    private Lista<String> tipoTramite;
    private String dependencia;
    private Expediente expediente;
    private Date fInicio;
    private Date fFinal;
    private Cola<String> historial;
    private String estado;

    public Tramites(String tipoTramite, String dependencia, Expediente expediente) {
        this.tipoTramite = new Lista<>();
        this.tipoTramite.agregar(tipoTramite);
        this.dependencia = dependencia;
        this.expediente = expediente;
        this.fInicio = new Date();
        this.fFinal = new Date();
        this.historial = new Cola<>();
        this.estado = "En proceso";
    }
    
    public Tramites(){
        this.tipoTramite = new Lista<>();
    }
    
    //public String getTipoTramite()
    
    public void GenerarTramite(){
        this.tipoTramite.agregar("CERTIFICADOS");
        this.tipoTramite.agregar("CONSTANCIA");
        this.tipoTramite.agregar("CARNET_UNIVERSITARIO");
        this.tipoTramite.agregar("LICENCIA");
        this.tipoTramite.agregar("RECLAMOS");
    }

    public Lista<String> getTipoTramite() {
        return tipoTramite;
    }

    public void setTipoTramite(Lista<String> tipoTramite) {
        this.tipoTramite = tipoTramite;
    }

    public String getDependencia() {
        return dependencia;
    }

    public void setDependencia(String dependencia) {
        this.dependencia = dependencia;
    }

    public Expediente getExpediente() {
        return expediente;
    }

    public void setExpediente(Expediente expediente) {
        this.expediente = expediente;
    }

    public Date getfInicio() {
        return fInicio;
    }

    public void setfInicio(Date fInicio) {
        this.fInicio = fInicio;
    }

    public Date getfFinal() {
        return fFinal;
    }

    public void setfFinal(Date fFinal) {
        this.fFinal = fFinal;
    }

    public Cola<String> getHistorial() {
        return historial;
    }

    public void setHistorial(Cola<String> historial) {
        this.historial = historial;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    
    
    /*
    private String Certificados = "CERTIFICADOS";
    private String Constancias = "CONSTANCIA";
    private String CarnetUniversitario = "CARNET_UNIVERSITARIO";
    private String CarnetDeLicencia = "LICENCIA";
    private String Reclamos = "RECLAMO";
    private String HistorialAcademico = "HISTORIAL_ACADEMICO"; 
    private String Beca = "BECA";
    */

    
}
