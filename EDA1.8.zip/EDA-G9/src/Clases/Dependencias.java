package Clases;

import TDA.Lista;



public class Dependencias {
    private String NombreDepe;
    private Lista<String> ListaDepe;

    public Dependencias() {
        this.ListaDepe = new Lista<>();   
        GenerarDepe();
    }
    
    public void GenerarDepe(){
        this.ListaDepe.agregar("AREA_RECEPCION_DOCUMENTOS");
        this.ListaDepe.agregar("AREA_TRAMITE_DOCUMENTARIO");
        this.ListaDepe.agregar("AREA_REGISTROS_ACADEMICOS");
    }

    public String getNombreDepe() {
        return NombreDepe;
    }

    public Lista<String> getListaDepe() {
        return ListaDepe;
    }
    public String buscarDependenciaPorNombre(String nombre) {
        for (int i = 0; i < ListaDepe.longitud(); i++) {
            if (ListaDepe.iesimo(i).equals(nombre)) {
                return ListaDepe.iesimo(i);
            }
        }
        return null;
    }
    
    
}
