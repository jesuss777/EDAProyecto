package TDA;
public class Nodo<T> {

    private T elemento;
    private Nodo<T> sgteNodo;

    public Nodo(T elemento) {
        this.elemento = elemento;
        this.sgteNodo = null;
    }
    public Nodo(T pElemento, Nodo<T> pSgteNodo) {
        this.elemento = pElemento;
        this.sgteNodo = pSgteNodo;
    }

    public void setElemento(T pElemento) {
        this.elemento = pElemento;
    }

    public T getElemento() {
        return this.elemento;
    }

    public void setSgteNodo(Nodo<T> pSgteNodo) {
        this.sgteNodo = pSgteNodo;
    }

    public Nodo<T> getSgteNodo() {
        return this.sgteNodo;
    }
}