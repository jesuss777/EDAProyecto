package Gestion;
import Clases.*;
import TDA.*;
public class GestionAdmin {
    private Lista<Administrador> GestionAdmin;

    public GestionAdmin() {
        this.GestionAdmin = new Lista<>();
    }
    
    public Lista<Administrador> getGestionAdmin() {
        return GestionAdmin;
    }

    public void setGestionAdmin(Lista<Administrador> GestionAdmin) {
        this.GestionAdmin = GestionAdmin;
    }
    
    public void AgregarAdmin(Administrador admin){
        GestionAdmin.agregar(admin);
    }
    
    public Administrador iesimo(int pos) {
        return GestionAdmin.iesimo(pos);
    }
}
