package Clases;
import java.util.Date;

public class Tramites {
    private Date Finicio;
    private Date Ffin;
    private String doc;

    public Tramites() {
        this.Finicio = new Date(); 
        this.Ffin = new Date();
        this.doc = "";
    }
    
    
    public Date getFinicio() {
        return Finicio;
    }
    public void setFinicio(Date finicio) {
        Finicio = finicio;
    }
    public Date getFfin() {
        return Ffin;
    }
     public void setFfin(Date ffin) {
        Ffin = ffin;
    }

    
}
