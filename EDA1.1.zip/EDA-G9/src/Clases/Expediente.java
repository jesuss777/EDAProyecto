package Clases;
public class Expediente {
    
    private int id;
    private int prioridad;
    private Interesado datosInteresado;
    private String asunto;
    private String docRef;
    private Tramites registro;
    private String estado;
    
    public Expediente(int id, int prioridad, Interesado datosInteresado, String asunto, String docRef) {
        this.id = id;
        this.prioridad = prioridad;
        this.datosInteresado = datosInteresado;
        this.asunto = asunto;
        this.docRef = docRef;
        this.estado = "En trámite";
        this.registro = new Tramites();
    }
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getPrioridad() {
        return prioridad;
    }
    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }
    public Interesado getDatosInteresado() {
        return datosInteresado;
    }
    public void setDatosInteresado(Interesado datosInteresado) {
        this.datosInteresado = datosInteresado;
    }
    public String getAsunto() {
        return asunto;
    }
    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }
    public String getDocRef() {
        return docRef;
    }
    public void setDocRef(String docRef) {
        this.docRef = docRef;
    }
    public Tramites getRegistro() {
        return registro;
    }
    public void setRegistro(Tramites registro) {
        this.registro = registro;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}
