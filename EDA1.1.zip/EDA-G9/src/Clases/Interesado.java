package Clases;
public class Interesado {
    private int DNI;
    private String Nombre;
    private int telefono;
    private String email;
    
    public Interesado(int DNI, String Nombre, String email, int telefono) {
        this.DNI = DNI;
        this.Nombre = Nombre;
        this.email = email;
        this.telefono = telefono;
    }
    
    public int getDNI() {
        return DNI;
    }
    public void setDNI(int DNI) {
        this.DNI = DNI;
    }
    
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    public int getTelefono() {
        return telefono;
    }
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }
    
    
}
