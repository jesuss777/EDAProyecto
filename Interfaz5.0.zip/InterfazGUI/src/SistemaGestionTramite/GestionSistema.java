/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;

import TDA.*;

/**
 *
 * @author User
 */
public class GestionSistema {
    private Lista<Administrador> listaUsuarios;
    private Lista<Interesado> listaInteresados;
    private Lista<Dependencia> listaDependencias;

    public GestionSistema() {
        this.listaUsuarios= new Lista<>();
        this.listaInteresados = new Lista<>();
        this.listaDependencias = new Lista<>();
    }
    
    public void agregarAdministrador(String nombreDeUsuario, String contraseña) {
        Administrador nuevoAdministrador = new Administrador(nombreDeUsuario, contraseña);
        listaUsuarios.agregar(nuevoAdministrador);
    }
    
    public void agregarInteresado(String nombre,int DNI) {
        Interesado nuevoInteresado= new Interesado(nombre,DNI);
        listaInteresados.agregar(nuevoInteresado);
    }
    
    public void mostrarInteresados() {
        int longitud = listaInteresados.longitud();
        for (int i = 1; i <= longitud; i++) {
            Interesado Interesado = listaInteresados.iesimo(i);
            if (Interesado != null) {
                System.out.print(Interesado.toString() + "\t");
            }
        }
        System.out.println();
    }
    
    public void agregarDependencia(String nombreDependencia) {
        Dependencia nuevaDependencia = new Dependencia(nombreDependencia);
        listaDependencias.agregar(nuevaDependencia);
    }
    
    public void mostrarDependencias() {
        int longitud = listaDependencias.longitud();
        for (int i = 1; i <= longitud; i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null) {
                System.out.print(dependencia.toString() + "\t");
            }
        }
        System.out.println();
    }
    
    public void agregarExpediente(String idExpediente, int prioridad, String nombreInteresado, int DNIInteresado, String asunto, String documentoReferencia, String nombreDependencia, String documentos ){
        Interesado Interesado = buscarInteresado(nombreInteresado, DNIInteresado);
        if (Interesado == null) {
            System.out.println("Interesado no encontrado.");
            return;
        }
        
        Dependencia dependencia = buscarDependencia(nombreDependencia);
        if (dependencia == null) {
            System.out.println("Dependencia no encontrada.");
            return;
        }
        
        Expediente nuevoExpediente = new Expediente(idExpediente, prioridad, Interesado, asunto, documentoReferencia, dependencia, documentos);
        nuevoExpediente.agregarDependenciaHistorial(nombreDependencia);
        dependencia.agregarExpediente(nuevoExpediente);
        
    }
    
    public void moverExpediente(String idExpediente, String nombreDependenciaDestino) {
        // Buscar el expediente
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente == null) {
            System.out.println("Expediente no encontrado.");
            return;
        }

        // Buscar la dependencia destino
        Dependencia dependenciaDestino = buscarDependencia(nombreDependenciaDestino);
        if (dependenciaDestino == null) {
            System.out.println("Dependencia destino no encontrada.");
            return;
        }

        // Mover el expediente
        Dependencia dependenciaActual = expediente.getDependencia();
        expediente = dependenciaActual.moverExpediente();
        if (expediente != null) {
            expediente.setDependencia(dependenciaDestino);
            expediente.agregarDependenciaHistorial(nombreDependenciaDestino);
            dependenciaDestino.agregarExpediente(expediente);
        }
    } 
    
    public void finalizarExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            expediente.finalizar();
        } else {
            System.out.println("Expediente no encontrado.");
        }
    }    
    
    public void mostrarHistorialExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            expediente.mostrarHistorialDependencias();
        } else {
            System.out.println("Expediente no encontrado.");
        }
    }
    
    private Expediente buscarExpediente(String idExpediente) {
        for (int i = 1; i <= listaDependencias.longitud(); i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null) {
                Expediente expediente = dependencia.buscarExpediente(idExpediente);
                if (expediente != null) {
                    return expediente;
                }
            }
        }
        return null;
    }
    
    private Interesado buscarInteresado(String nombre, int dni){
        int longitud = listaInteresados.longitud();
        for (int i = 1; i <= longitud; i++) {
            Interesado Interesado = listaInteresados.iesimo(i);
            if (Interesado != null && Interesado.getNombre().equals(nombre) && Interesado.getDNI() == dni) {
                return Interesado;
            }
        }
        return null;
    }
    
    private Dependencia buscarDependencia(String nombreDependencia) {
        int longitud = listaDependencias.longitud();
        for (int i = 1; i <= longitud; i++) {
            Dependencia dependencia = listaDependencias.iesimo(i);
            if (dependencia != null && dependencia.getNombre().equals(nombreDependencia)) {
                return dependencia;
            }
        }
        return null;
    }
    
    public void mostrarEstadoExpediente(String idExpediente) {
        Expediente expediente = buscarExpediente(idExpediente);
        if (expediente != null) {
            System.out.println(expediente.obtenerDescripcionCompleta());
        } else {
            System.out.println("Expediente no encontrado.");
        }
    }    
}
