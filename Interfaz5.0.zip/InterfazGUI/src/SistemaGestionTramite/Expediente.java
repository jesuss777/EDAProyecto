/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
import java.time.LocalDateTime;

import TDA.*;

/**
 *
 * @author User
 */
public class Expediente {
    private String idExpediente;
    private int prioridad;
    private Interesado usuario;
    private String asunto;
    private String documentoReferencia;
    private Dependencia dependencia;
    private Lista<String> historialExpediente;
    private String documentos;
    private String estado;
    private LocalDateTime fechaHoraInicio,fechaHoraFin;

    public Expediente(String idExpediente, int prioridad, Interesado usuario, String asunto, String documentoReferencia, Dependencia dependencia, String documentos) {
        this.idExpediente = idExpediente;
        this.prioridad = prioridad;
        this.usuario = usuario;
        this.asunto = asunto;
        this.documentoReferencia = documentoReferencia;
        this.dependencia = dependencia;
        this.historialExpediente = new Lista<>();
        this.documentos = documentos;
        this.estado = "En Proceso";
        this.fechaHoraInicio = LocalDateTime.now();
        this.fechaHoraFin = null;
    }
    
    public void agregarDependenciaHistorial(String dependencia){
        historialExpediente.agregar(dependencia);
    }
    
    public void mostrarHistorialDependencias() {
        historialExpediente.mostrar();
    }
    
    public void finalizar() {
        this.estado = "Finalizado";
        this.fechaHoraFin = LocalDateTime.now();
    }
    

    
    public String obtenerDescripcionCompleta() {
        return "ID: " + idExpediente + "\n" +
               "Prioridad: " + prioridad + "\n" +
               "Usuario: " + usuario + "\n" +
               "Asunto: " + asunto + "\n" +
               "Documento Referencia: " + documentoReferencia + "\n" +
               "Dependencia Actual: " + dependencia.getNombre() + "\n" +
               "Estado: " + estado + "\n" +
               "Fecha y Hora de Inicio: " + fechaHoraInicio + "\n" +
               (fechaHoraFin != null ? "Fecha y Hora de Finalización: " + fechaHoraFin : "");
    }
    
    public String getIdExpediente() {
        return idExpediente;
    }

    public void setIdExpediente(String idExpediente) {
        this.idExpediente = idExpediente;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public Interesado getUsuario() {
        return usuario;
    }

    public void setUsuario(Interesado usuario) {
        this.usuario = usuario;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public String getDocumentoReferencia() {
        return documentoReferencia;
    }

    public void setDocumentoReferencia(String documentoReferencia) {
        this.documentoReferencia = documentoReferencia;
    }

    public Dependencia getDependencia() {
        return dependencia;
    }

    public void setDependencia(Dependencia dependencia) {
        this.dependencia = dependencia;
    }

    public Lista<String> getHistorialExpediente() {
        return historialExpediente;
    }

    public void setHistorialExpediente(Lista<String> historialExpediente) {
        this.historialExpediente = historialExpediente;
    }

    public String getDocumentos() {
        return documentos;
    }

    public void setDocumentos(String documentos) {
        this.documentos = documentos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public LocalDateTime getFechaHoraInicio() {
        return fechaHoraInicio;
    }

    public void setFechaHoraInicio(LocalDateTime fechaHoraInicio) {
        this.fechaHoraInicio = fechaHoraInicio;
    }

    public LocalDateTime getFechaHoraFin() {
        return fechaHoraFin;
    }

    public void setFechaHoraFin(LocalDateTime fechaHoraFin) {
        this.fechaHoraFin = fechaHoraFin;
    }

    

}
