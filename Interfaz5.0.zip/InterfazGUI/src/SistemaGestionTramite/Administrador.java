/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
/**
 *
 * @author User
 */
public class Administrador {
    private String nombreDeUsuario;
    private String contraseña;
    

    public Administrador(String nombreDeUsuario, String contraseña) {
        this.nombreDeUsuario = nombreDeUsuario;
        this.contraseña = contraseña;
    }

    public boolean validarAcceso(String username, String password) {
        return this.nombreDeUsuario.equals(username) && this.contraseña.equals(password);
    }

    public String getNombreDeUsuario() {
        return nombreDeUsuario;
    }

    public void setNombreDeUsuario(String nombreDeUsuario) {
        this.nombreDeUsuario = nombreDeUsuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
    
    
}
