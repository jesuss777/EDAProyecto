/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SistemaGestionTramite;
import TDA.*;
import java.util.Scanner;
import java.util.Date;

/**
 *
 * @author User
 */
public class Sistema {
    public static void main(String[] args) {
        // Crear el sistema de gestión
        GestionSistema gestionSistema = new GestionSistema();

        // Agregar interesados
        gestionSistema.agregarInteresado("Juan Perez", 12345678);
        gestionSistema.agregarInteresado("Ana Gomez", 87654321);

        // Mostrar interesados
        System.out.println("interesados:");
        gestionSistema.mostrarInteresados();

        // Agregar dependencias
        gestionSistema.agregarDependencia("Dependencia 1");
        gestionSistema.agregarDependencia("Dependencia 2");

        // Mostrar dependencias
        System.out.println("Dependencias:");
        gestionSistema.mostrarDependencias();

        // Agregar expediente
        gestionSistema.agregarExpediente("EXP001", 1, "Juan Perez", 12345678, "Solicitud de documento", "DOC001", "Dependencia 1", "Documento inicial");
        gestionSistema.agregarExpediente("EXP002", 2, "Ana Gomez", 87654321, "Queja administrativa", "DOC002", "Dependencia 1", "Queja inicial");

        // Mover expediente de una dependencia a otra
        gestionSistema.moverExpediente("EXP001", "Dependencia 2");

        // Finalizar expediente
        gestionSistema.finalizarExpediente("EXP002");

        // Mostrar historial de expedientes
        System.out.println("Historial del Expediente EXP001:");
        gestionSistema.mostrarHistorialExpediente("EXP001");

        System.out.println("Historial del Expediente EXP002:");
        gestionSistema.mostrarHistorialExpediente("EXP002");
        gestionSistema.mostrarEstadoExpediente("EXP002");
        
    }
    
 
}
    

